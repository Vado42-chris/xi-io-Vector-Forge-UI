#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node &> /dev/null; then
    echo "Node.js not found. Please install Node.js 18+"
    exit 1
fi
if ! command -v serve &> /dev/null; then
    npm install -g serve
fi
serve -s dist -l 3000
